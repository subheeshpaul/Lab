export class CustomerModel {
    customerName: string;
    customerAddress1: string;
    customerAddress2: string;
    customerCity: string
    customerCounty: string;
    customerCountry: string
  
  }