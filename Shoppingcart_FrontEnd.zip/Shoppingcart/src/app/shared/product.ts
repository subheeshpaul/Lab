﻿export interface Product {
  id: number;
  unitPrice: number;
  name: string;
  unitWeight: number
}